/*
** $Header: /u/drspeech/src/rasta/RCS/acconfig.h,v 1.1 1996/12/07 01:33:22 davidj Exp $
**
** acconfig.h file for rasta
*/

#undef HAVE_LIBESPS
#undef HAVE_LIBMAT
#undef HAVE_LIBSOCKET
#undef HAVE_LIBSP
